


def valid_int(value):
    if isinstance(value, int) and value > 0:
        return True
    else:
        return False
